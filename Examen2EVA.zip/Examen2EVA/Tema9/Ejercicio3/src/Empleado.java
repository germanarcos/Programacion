public class Empleado {
	private int sueldo;
	String nombre;
	protected String direccion;
	public int edad;
}