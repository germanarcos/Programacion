import pack2.EmpleadoEspecial;
public class Jefe extends Empleado {
	EmpleadoEspecial nuevoAtrb;
	public Jefe() {
	}
}