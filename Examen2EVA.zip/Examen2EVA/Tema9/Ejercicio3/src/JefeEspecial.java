
import pack2.EmpleadoEspecial;

public class JefeEspecial extends EmpleadoEspecial {
	public JefeEspecial() {
	}
}