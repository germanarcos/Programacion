package pack2;

public class EmpleadoEspecial {
	public String nombreEs;
	private float sueldoEs;
	protected String direccionEs;
	int edad;
}
