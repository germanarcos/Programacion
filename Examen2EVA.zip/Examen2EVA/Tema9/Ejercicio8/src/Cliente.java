
public class Cliente implements Persona {
	public void pedirTodosDatos() {
	};

	Domicilio casa;
	public void visualizarTodosDatos() {
		System.out.println(nombreEmpresa);
	};

}
