
public class Domicilio {
	String ciudad;
	String calle;
	String numero;
	char puerta;
	public Domicilio(String ciudad, String calle, String numero, char puerta) {
		this.ciudad = ciudad;
		this.calle = calle;
		this.numero = numero;
		this.puerta = puerta;
	}

}
