
public class Empleado implements Persona {
	Empleado(){
		
	}
	//TODO
	String nombre; 
	String appellido;
	Empleado(String nombre,String apellido,String ciudad,String calle,char puerta){
		this.nombre=nombre;
		this.nombre=nombre;
		this.nombre=nombre;
	}
	public void pedirTodosDatos() {
	};

	Domicilio casa;
	public void visualizarTodosDatos() {
	};

}
