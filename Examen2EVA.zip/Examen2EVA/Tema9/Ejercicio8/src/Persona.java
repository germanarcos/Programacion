public interface Persona {
	public abstract void pedirTodosDatos();

	public abstract void visualizarTodosDatos();

	String nombreEmpresa = "Croquetas S.A.";
}
