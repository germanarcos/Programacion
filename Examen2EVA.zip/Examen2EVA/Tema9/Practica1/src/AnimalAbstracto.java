/**
 *
 * @author Germ�n Arcos Arag�n
 */
public class AnimalAbstracto implements Animal {
    protected String nombre;
    
    /* Implementa viveUnaHora para que sea definido m�s adelante
     * en cada clase animal seg�n su actividad y dependiendo de la hora que sea.
     */
    @Override
    public void viveUnaHora(int hora){
    }

    /* Da un nombre a un animal instanciado.
     * Implementa el m�todo setNombre de la interfaz animal.
     */
    
    @Override
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
