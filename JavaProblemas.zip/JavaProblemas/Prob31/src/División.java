
public class Divisi�n {
	public static void Division(int m, int n){
		int resultado = m/n;
		System.out.println("El resultado de la divisi�n de " + m + " + " + n + " es: " + resultado);
	}
}
