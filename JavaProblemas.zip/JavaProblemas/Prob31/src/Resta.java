
public class Resta {
	public static void Resta(int m, int n){
		int resultado;
		resultado = m - n;
		System.out.println("El resultado de la resta de " + m + " + " + n + " es: " + resultado);
	}
}
