
public class Suma {

	public static void Suma(int m,int n){
		int resultado = m + n;
		System.out.println("El resultado de la suma de " + m + " + " + n + " es: " + resultado);
	}
}
