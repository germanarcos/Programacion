
public class multiplicacion {
	public static void multiplicacion(int m, int n){
		int resultado = m * n;
		System.out.println("El resultado de la multiplicaci�n de " + m + " + " + n + " es: " + resultado);
	}
}
