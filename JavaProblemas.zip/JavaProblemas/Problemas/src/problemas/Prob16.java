/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problemas;

/**
 *
 * @author usuario
 */
public class Prob16 {
    public static void Prob16(){
        for(int i=1;i<11;i++){
            for(int k=1;k<11;k++){
                System.out.println(k);
            }
        }
    }
    
}
